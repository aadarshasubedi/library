<!DOCTYPE <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>
		<?php 
			if(isset($pageTitle)){
				echo $pageTitle;
			} 
		?>
	</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" media="screen" href="style.css" />
	<link rel="stylesheet" href= "js/bootstrap.min"/>  
	<link href="css/login-style.css" rel="stylesheet">
  	<script src="js/jquery.min"></script>
	
	<script type="text/javascript" src="js/instascan.min.js"></script>
</head>
<body>
<!--<header>
    <nav>
        <ul>
			<li>
				<a href="index.php"><img src="includes/logo.PNG" alt="FabLab Bohol" height="200" width="1300"></a>
			</li>
        </ul>
    </nav>
</header>-->